import mysql from 'mysql'

export const handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: "tables4udb.cvms8kiuo53g.us-east-1.rds.amazonaws.com",
      user: "calcAdmin",
      password: "Sabaidee2035*",
      database: "tables4U"
  });
  
  let FindPin = (pin_input) => {
        return new Promise((resolve, reject) => {
            if(pin_input == "1234"){ //this should also change at some point 
                return resolve(pin_input, "admin") //idk if this is the best thing to return? 
            }
            else{
                pool.query("SELECT * FROM tables4U.Restaurants WHERE pin=?",
                    [pin_input], (error, rows) => {
                    if (error) { return reject(error) }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0].pin, "manager")
                    } else {
                        return reject("Unable to locate user pin '" + pin_input + "'")
                    }
                }); 
            }
            
        });
  }
  
  const pin = await FindPin(event.arg1)

  pool.end()
  
  return { 
    statusCode: 200,
    body: JSON.stringify(pin)
  }
}