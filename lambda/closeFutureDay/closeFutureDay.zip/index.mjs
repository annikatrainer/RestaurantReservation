import mysql from 'mysql'

export const handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
    host: "tables4udb.cvms8kiuo53g.us-east-1.rds.amazonaws.com",
    user: "calcAdmin",        
    password: "Sabaidee2035*",  
    database: "tables4U"        
})
 
// can only do this when the restaurant is active
// date format is 2008-08-22

// add row to Closed_Days table
  let closeFutureDay= (date, restaurant_ID) => {
// check if there is a restaurant with that ID
    
      return new Promise((resolve, reject) => { // wrap the query in a promise
            pool.query(`INSERT INTO tables4U.Closed_Days 
       (date, restaurant_ID) 
       VALUES (?, ?,) 
       ON DUPLICATE KEY UPDATE 
       date = VALUES(date), restaurant_ID = VALUES(restaurant_ID);`,
      [date, restaurant_ID], (error, rows) => { // query the DB
 // query the DB
                if (error) { return reject(error); } // reject the promise if there's an error
                if ((rows) && (rows.affectedRows == 1)) {  // if the query was successful
                  console.log("Successfully added" + " to the table", date); 
                  return resolve(true);  
                } else {
                  console.log("Date was not added:", date);

                    return resolve(false);
                }
            });
      });
  }

  let response
  



  //make it return the information from http stuff
  try {
    const result = await openFutureDay(event.date,event.restaurant_ID) // call the function
    if (result) { 
      response = { statusCode: 200, result: { "success" : true }}
    } else {
      response = { statusCode: 400, error: "Restaurant does not exist" }
    }
  } catch (err) {
     response = { statusCode: 400, error: err }
  }
    
  pool.end()     // close DB connections

  return response;
}

